﻿using Microsoft.VisualStudio.TestPlatform.ObjectModel;
using Tutorial3.Models;

public class EmpDeptSalgradeTests
{
    // 1. Simple WHERE filter
    // SQL: SELECT * FROM Emp WHERE Job = 'SALESMAN';
    [Fact]
    public void ShouldReturnAllSalesmen()
    {
        var emps = Database.GetEmps(); //bierze cala liste pracownikow z bazy danych

        List<Emp> result = (from emp in emps
            where emp.Job == "SALESMAN"
            select emp).ToList(); //toList zmienia wynik na liste 

        Assert.Equal(2, result.Count); //test oczekuje ze znajdziee dokladnie dwoch takich pracownikow
        Assert.All(result,
            e => Assert.Equal("SALESMAN",
                e.Job)); //czyli: upewnij się że KAŻDY z tej listy faktycznie ma Job = "SALESMAN"
    }

    // 2. WHERE + OrderBy
    // SQL: SELECT * FROM Emp WHERE DeptNo = 30 ORDER BY Sal DESC;
    [Fact]
    public void ShouldReturnDept30EmpsOrderedBySalaryDesc()
    {
        var emps = Database.GetEmps();

        List<Emp> result = (from emp in emps
            where emp.DeptNo == 30
            orderby emp.Sal descending
            select emp).ToList();
        ;

        Assert.Equal(2, result.Count);
        Assert.True(result[0].Sal >= result[1].Sal);
    }

    // 3. Subquery using LINQ (IN clause)
    // SQL: SELECT * FROM Emp WHERE DeptNo IN (SELECT DeptNo FROM Dept WHERE Loc = 'CHICAGO');
    [Fact]
    public void ShouldReturnEmployeesFromChicago()
    {
        var emps = Database.GetEmps();
        var depts = Database.GetDepts();

        var deptNoChicago =
            (from dept in depts where dept.Loc == "CHICAGO" select dept.DeptNo)
            .ToList(); //musi byc select bo chce dostać same numery działów a nie cale obiekty
        List<Emp> result = (from emp in emps
            where deptNoChicago.Contains(emp.DeptNo)
            select emp).ToList();


        Assert.All(result, e => Assert.Equal(30, e.DeptNo));
    }

    // 4. SELECT projection
    // SQL: SELECT EName, Sal FROM Emp;
    [Fact]
    public void ShouldSelectNamesAndSalaries()
    {
        var emps = Database.GetEmps();

        var result = (from emp in emps
            select new { emp.EName, emp.Sal }).ToList();

        Assert.All(result, r =>
        {
            Assert.False(string.IsNullOrWhiteSpace(r.EName));
            Assert.True(r.Sal > 0);
        });
    }

    // 5. JOIN Emp to Dept
    // SQL: SELECT E.EName, D.DName FROM Emp E JOIN Dept D ON E.DeptNo = D.DeptNo;
    [Fact]
    public void ShouldJoinEmployeesWithDepartments()
    {
        var emps = Database.GetEmps();
        var depts = Database.GetDepts();

        var result = from emp in emps
                join dept in depts on emp.DeptNo equals dept.DeptNo
                select new { emp.EName, dept.DName }
            ;

        Assert.Contains(result, r => r.DName == "SALES" && r.EName == "ALLEN");
    }

    // 6. Group by DeptNo
    // SQL: SELECT DeptNo, COUNT(*) FROM Emp GROUP BY DeptNo;
    [Fact]
    public void ShouldCountEmployeesPerDepartment()
    {
        var emps = Database.GetEmps();

        var result = (from emp in emps
                group emp by emp.DeptNo
                into
                    g // pogrupuj mi pracowników na podstawie numeru działu DeptNo i  nazywamy ta grupe g dzieki czemu mozemy pozniej z ta grupa robic jeszcze rozne rzeczy
                select new { DeptNo = g.Key, Count = g.Count() })
            .ToList(); //weź numer działu i policz ile osób w nim pracuje

        Assert.Contains(result, g => g.DeptNo == 30 && g.Count == 2);
    }

    // 7. SelectMany (simulate flattening)
    // SQL: SELECT EName, Comm FROM Emp WHERE Comm IS NOT NULL;
    [Fact]
    public void ShouldReturnEmployeesWithCommission()
    {
        var emps = Database.GetEmps();

        var result = (from emp in emps
            where emp.Comm != null
            select new { emp.EName, emp.Comm }).ToList();

        Assert.All(result, r => Assert.NotNull(r.Comm));
    }

    // 8. Join with Salgrade
    // SQL: SELECT E.EName, S.Grade FROM Emp E JOIN Salgrade S ON E.Sal BETWEEN S.Losal AND S.Hisal;
    [Fact]
    public void ShouldMatchEmployeeToSalaryGrade()
    {
        var emps = Database.GetEmps();
        var grades = Database.GetSalgrades();

        var result = from emp in emps
            from gr in grades
            where emp.Sal <= gr.Losal && emp.Sal >= gr.Grade
            select new
                { emp.EName, gr.Grade };

        Assert.Contains(result, r => r.EName == "ALLEN" && r.Grade == 3);
    }

    // 9. Aggregation (AVG)
    // SQL: SELECT DeptNo, AVG(Sal) FROM Emp GROUP BY DeptNo;
    [Fact]
    public void ShouldCalculateAverageSalaryPerDept()
    {
        var emps = Database.GetEmps();

        var result = from emp in emps
            group emp by emp.DeptNo
            into g
            select new { DeptNo = g.Key, AvgSal = g.Average(s => s.Sal) };

        Assert.Contains(result, r => r.DeptNo == 30 && r.AvgSal > 1000);
    }

    // 10. Complex filter with subquery and join
    // SQL: SELECT E.EName FROM Emp E WHERE E.Sal > (SELECT AVG(Sal) FROM Emp WHERE DeptNo = E.DeptNo);
    [Fact]
    public void ShouldReturnEmployeesEarningMoreThanDeptAverage()
    {
        var emps = Database.GetEmps();

        var result = (from emp in emps
            where emp.Sal> emps.Where(x=>x.DeptNo==emp.DeptNo).Average(x=>x.Sal)
            select emp.EName).ToList();

        Assert.Contains("ALLEN", result);
    }
}